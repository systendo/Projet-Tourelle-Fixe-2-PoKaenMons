#include <m8c.h>
#include "PSoCAPI.h"
#include "const.h"
#include "camgauche.h"
#include "camdroite.h"
#include "initialisationblock.h"

/**
 * \fn Block InitialisationBlock(Block block)
 * \brief Initialise les différentes variables d'une structure Block à 0.
 * \param 
 * \return Retourne le Block modifié
 */

Block InitialisationBlock(Block block){
	block.checksum = 0;
	block.signature = 0;
	block.x = 0;
	block.y = 0;
	block.width = 0;
	block.height = 0;
	return (block) ;
}	

Block ValeurBlockDroit ( Block block) {
	block.checksum = getWord_CamDroite();
	block.signature = getWord_CamDroite();
	block.x = getWord_CamDroite();
	block.y = getWord_CamDroite();
	block.width = getWord_CamDroite();
	block.height = getWord_CamDroite();
	return (block) ;
}


Block ValeurBlockGauche ( Block block) {
	block.checksum = getWord_CamGauche();
	block.signature = getWord_CamGauche();
	block.x = getWord_CamGauche();
	block.y = getWord_CamGauche();
	block.width = getWord_CamGauche();
	block.height = getWord_CamGauche();
	return (block) ;
}


void EnvoiBlock ( Block block){
	UART_PutSHexInt(block.signature);
	UART_PutSHexInt(block.x);
	UART_PutSHexInt(block.y);
	UART_PutSHexInt(block.width);
	UART_PutSHexInt(block.height);
}