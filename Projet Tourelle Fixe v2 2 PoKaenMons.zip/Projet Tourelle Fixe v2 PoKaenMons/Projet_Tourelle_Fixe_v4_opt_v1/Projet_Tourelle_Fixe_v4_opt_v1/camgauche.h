/*!
     *  \brief Prototypes des fonctions utilisés pour communiquer avec la caméra de gauche 
     */
	

BYTE getByte_CamGauche(char out);
int getWord_CamGauche(void);
int getStart_CamGauche(void);