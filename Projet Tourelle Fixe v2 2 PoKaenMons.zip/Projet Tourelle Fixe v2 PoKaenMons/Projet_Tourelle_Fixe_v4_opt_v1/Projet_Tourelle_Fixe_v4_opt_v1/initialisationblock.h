Block InitialisationBlock (Block) ;
Block ValeurBlockDroit(Block) ;
Block ValeurBlockGauche(Block) ;
void EnvoiBlock(Block);