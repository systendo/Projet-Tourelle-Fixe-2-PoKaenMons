/*!
     *  \brief Prototype de la fonction affichage 
     */
	
void affichage(	int signature_aff_gauche, 
				int x_aff_gauche, 
				int y_aff_gauche, 
				int signature_aff_droite,
				int x_aff_droite,
				int y_aff_droite);