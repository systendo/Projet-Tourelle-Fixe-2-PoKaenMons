/*!
     *  \brief Prototypes des fonctions utilisés pour communiquer avec la caméra de droite 
     */

BYTE getByte_CamDroite(char out);
int getWord_CamDroite(void);
int getStart_CamDroite(void);