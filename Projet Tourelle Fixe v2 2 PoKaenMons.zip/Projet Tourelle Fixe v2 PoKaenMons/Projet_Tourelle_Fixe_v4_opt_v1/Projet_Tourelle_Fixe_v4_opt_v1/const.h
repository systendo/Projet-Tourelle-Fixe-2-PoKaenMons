#define PIXY_START_WORD             0xaa55
#define PIXY_START_WORD_CC          0xaa56
#define PIXY_START_WORDX            0x55aa


#define PIXY_SYNC_BYTE              0x5a  /// to sync SPI data
#define PIXY_SYNC_BYTE_DATA         0x5b  /// to sync/indicate SPI send data


typedef struct
{
	int signature;
	int checksum;
	int x;
	int y;
	int width;
	int height;
} Block;