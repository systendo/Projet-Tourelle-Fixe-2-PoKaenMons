/**
 * \file 		main.c
 * \brief 		Programme de tests.
 * \author 		Systendo
 * \version 	4.1
 * \date 		23 septembre 2016
 *
 * Programme qui acquiert les données en provenance des deux PixyCams et qui les envoie au PC via Xbee.
 * Tests avec 2 Pokeanmon
 */

#include <m8c.h>
#include "PSoCAPI.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "const.h"
#include "camgauche.h"
#include "camdroite.h"
#include "affichage.h"
#include "initialisationblock.h"

unsigned char Flag_ISR_Timer;
unsigned char Flag_ISR_Timer_fast;
char count;


void main(void)
{
	Block camGauche1;
	Block camGauche2;
	Block camDroite1;
	Block camDroite2;
	
	int test_gauche;
	int test_droit;
	
	SPIM_CamGauche_Start(SPIM_CamGauche_SPIM_MODE_0 | SPIM_CamGauche_SPIM_MSB_FIRST);
	SPIM_CamDroite_Start(SPIM_CamDroite_SPIM_MODE_0 | SPIM_CamDroite_SPIM_MSB_FIRST);
	UART_Start(UART_PARITY_NONE);	
	TimerCamera_Start();
	TimerCamera_EnableInt();
	Flag_ISR_Timer = 0;
	LCD_Start();
	
	///Enable the global and local interrupts 
	M8C_EnableGInt;

	while(1)
	{
		if (Flag_ISR_Timer == 1)
		{
			LED_Invert();
			Flag_ISR_Timer_fast = 0;
			
			while(getStart_CamGauche() == 0) 						/// On cherche le début de frame aa55
			{ 
				if (Flag_ISR_Timer_fast == 1) 						///Attente d'un Pokeanmon pendant 50ms
				{
					camGauche1 = InitialisationBlock(camGauche1) ; 
					camGauche2 = InitialisationBlock(camGauche2) ;
					Flag_ISR_Timer_fast = 0;
					break;
				}
			}

			camGauche1 = ValeurBlockGauche(camGauche1);			/// Informations propres à la première signature sur la caméra de gauche ( premier Pokaenmon)
			getWord_CamGauche(); 								/// 0xAA55
			camGauche2 = ValeurBlockGauche(camGauche2);			/// Informations propres à la deuxième signature sur la caméra de gauche ( deuxième Pokaenmon)
				
			Flag_ISR_Timer_fast = 0;
			while(getStart_CamDroite() == 0) 					/// On cherche le début de frame aa55
			{ 
				if (Flag_ISR_Timer_fast == 1)
				{
					Flag_ISR_Timer_fast = 0;
					break;
				}
			}

			camDroite1 = ValeurBlockDroit(camDroite1);			/// Informations propres à la première signature sur la caméra de droite ( premier Pokaenmon)
			getWord_CamDroite(); 								/// 0xAA55
			camDroite2 = ValeurBlockDroit(camDroite2);			/// Informations propres à la deuxième signature sur la caméra de droite ( deuxième Pokaenmon)
			
			affichage(	camGauche2.signature, camGauche2.x, camGauche2.y,
						camDroite2.signature, camDroite2.x, camDroite2.y);
			
			EnvoiBlock (camGauche1) ;
			EnvoiBlock (camDroite1) ;
			EnvoiBlock (camGauche2) ;
			EnvoiBlock (camDroite2) ;
			
			Flag_ISR_Timer = 0;
		}
	}
	
	return;
}



#pragma interrupt_handler TimerCamera_ISR_C
void TimerCamera_ISR_C(void)
{
	count++;
	if(count>=4)
	{
		count = 0;
		Flag_ISR_Timer = 1;
	}
	
	Flag_ISR_Timer_fast = 1;
	PRT1DR^=0x01 ;
}