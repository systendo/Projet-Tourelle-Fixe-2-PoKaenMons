var searchData=
[
  ['affichage',['affichage',['../affichage_8c.html#a0b440ee93e468e9a5455c5edaad0660c',1,'affichage(int signature_aff_gauche, int x_aff_gauche, int y_aff_gauche, int signature_aff_droite, int x_aff_droite, int y_aff_droite):&#160;affichage.c'],['../affichage_8h.html#a0b440ee93e468e9a5455c5edaad0660c',1,'affichage(int signature_aff_gauche, int x_aff_gauche, int y_aff_gauche, int signature_aff_droite, int x_aff_droite, int y_aff_droite):&#160;affichage.c']]]
];
