var searchData=
[
  ['watchdog_5fenable',['WATCHDOG_ENABLE',['../backup_2globalparams_8h.html#a888ef2f473713cb9783eb015e32a366c',1,'WATCHDOG_ENABLE():&#160;globalparams.h'],['../lib_2globalparams_8h.html#a888ef2f473713cb9783eb015e32a366c',1,'WATCHDOG_ENABLE():&#160;GlobalParams.h']]]
];
